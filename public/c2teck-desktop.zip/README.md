# C2Teck S.A.C. — Aplicación de Escritorio

Envoltorio nativo (Electron) de la plataforma C2Teck. Ejecuta el ecosistema
ERP Systeck, Zigma Apps, ParkView TI y Hideez FIDO2 en una ventana de
escritorio dedicada — sin barra de navegador, ícono propio y menú nativo.

## 🚀 Ejecutar en modo desarrollo

Requisitos: Node.js 18+ y npm.

```bash
npm install
npm start
```

Se abrirá una ventana con la plataforma C2Teck.

## 📦 Generar instalador / ejecutable

Desde la carpeta `electron/`:

```bash
# Windows (.exe)
npm run package:win

# macOS (.app)
npm run package:mac

# Linux
npm run package:linux
```

El binario se generará en `electron/dist/`.

## ⚙️ Configuración

La URL de la plataforma se define en `main.cjs` (`APP_URL`) o mediante la
variable de entorno `C2TECK_URL`:

```bash
C2TECK_URL=https://mi-tenant.c2teck.com.pe npm start
```

## 🎨 Ícono

Reemplaza `icon.png` (1024×1024 recomendado) para personalizar el ícono.
