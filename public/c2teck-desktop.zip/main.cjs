// C2Teck S.A.C. — Desktop Shell (Electron)
// Envuelve la plataforma web C2Teck en una ventana de escritorio nativa.
const { app, BrowserWindow, Menu, shell } = require("electron");
const path = require("path");

// URL de la plataforma. Puede sobreescribirse con la variable C2TECK_URL.
const APP_URL =
  process.env.C2TECK_URL ||
  "https://id-preview--31b84888-f163-417f-9649-c355ef54b560.lovable.app";

function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1024,
    minHeight: 640,
    backgroundColor: "#0A0D14",
    title: "C2Teck S.A.C. — Plataforma Empresarial",
    icon: path.join(__dirname, "icon.png"),
    autoHideMenuBar: true,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
    },
  });

  win.loadURL(APP_URL);

  // Abrir enlaces externos en el navegador del sistema
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (!url.startsWith(APP_URL)) {
      shell.openExternal(url);
      return { action: "deny" };
    }
    return { action: "allow" };
  });
}

// Menú minimalista tipo aplicación empresarial
const menuTemplate = [
  {
    label: "Archivo",
    submenu: [
      { role: "reload", label: "Recargar" },
      { role: "forceReload", label: "Recargar forzado" },
      { type: "separator" },
      { role: "quit", label: "Salir" },
    ],
  },
  {
    label: "Ver",
    submenu: [
      { role: "zoomIn", label: "Acercar" },
      { role: "zoomOut", label: "Alejar" },
      { role: "resetZoom", label: "Restablecer zoom" },
      { type: "separator" },
      { role: "togglefullscreen", label: "Pantalla completa" },
    ],
  },
  {
    label: "Ayuda",
    submenu: [
      {
        label: "Sitio Web C2Teck",
        click: () => shell.openExternal("https://www.c2teck.com.pe"),
      },
    ],
  },
];

app.whenReady().then(() => {
  Menu.setApplicationMenu(Menu.buildFromTemplate(menuTemplate));
  createWindow();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") app.quit();
});
